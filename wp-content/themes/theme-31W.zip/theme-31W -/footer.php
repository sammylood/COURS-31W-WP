    <footer class="pied">
        <section class="global">
            <div></div>
            <div>Auteur : Samuel Dorneval</div>
            <div></div>
        </section>
    </footer>
    <?php wp_footer() ?>
    </body>

    </html>